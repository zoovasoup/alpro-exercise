public class main {
  public static void main(String[] args) {
    System.out.println("Welcome to Java\nLearning Java Now,\nand Programming is fun.");
  }
}
